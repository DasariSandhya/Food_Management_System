<?php
    //include_once('conncet.php');
    $con=new mysqli("localhost","root","","project");
    if($con->connect_error)
{
	die("failed to connect:".$con->connect_error);
}
else
{
	$stmt="select * from fooddetails";
    //$query="select * from fooddetails";
    $result=$con->query($stmt);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title> WFM</title>
    <meta name="author" content="Codeconvey" />
    
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <link rel="stylesheet" href="css/login-page.css">
    

    <link rel="stylesheet" href="css/demo.css" />
    <style>
        table.center{
            margin-left:auto;
            margin-right:auto;
            width:80%

        }
        </style>
	
</head>
<body>

<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        	<div class="rt-heading"><br><br><br>
            	<h1>FOOD MANAGEMENT SYSTEM</h1>
                <p>You waste life when, you waste good food</p>
            </div>
        </div>
    </div>
</header>
<table class="center" border="5" cellspacing="0"  >
    <tr>
        <th colspan="5" align="center" height="50" > <h1>food details<h1> </th>
    </tr>
    <tr style="width:500">
        <th align="center" height="30" >User Name</th>
        <th align="center" height="30">Address</th>
        <th align="center" height="30">Quantity</th>
        <th align="center" height="30">No_of_items</th>
        <th align="center" height="30">Action</th>
        
    </tr>
    <?php
        while($rows=mysqli_fetch_assoc($result))
        {
    ?>
            <tr>
                <td align="center" height="30"><?php echo $rows['Username'] ?></td>
                <td align="center" height="30"><?php echo $rows['Address'] ?></td>
                <td align="center" height="30"><?php echo $rows['Quantity'] ?></td>
                <td align="center" height="30"><?php echo $rows['Items'] ?></td>
                <td align="center" height="30"><a href="delete.php?Username=<?php echo $rows['Username'];?> ">Accept</a></td>
                <!--<td align="center" height="30"><input type="button"value="button" onclick="delete.php?rn=$rows['Username']"></td>-->

            </tr>
    <?php
        }
    ?>
</table>
</body>
</html>