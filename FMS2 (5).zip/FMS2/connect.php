<?PHP
 //mysqli_connect('localhost','root','');
 //mysqli_select_db('project');
 $con=new mysqli("localhost","root","","project");
?>