<?php     

ini_set( "SMTP", "ssl://smtp.gmail.com" ); 
ini_set( "smtp_port", "425" );
ini_set("username","sandyasandy2220@gmail");  
ini_set("password","Sandhya@123");
$con=new mysqli("localhost","root","","project");
if(! $con)
{
die('Connection Failed'.mysql_error());
}

//mysql_select_db($database,$con);
if(isset($_REQUEST['submit'])!='')
{
if($_REQUEST['Username']=='' || $_REQUEST['Address']=='' || $_REQUEST['Quantity']=='' || $_REQUEST['Items']=='')
{
echo "please fill the empty field.";
}
else
{
$sql="insert into fooddetails(Username,Address,Quantity,Items) values ('".$_REQUEST['Username']."', '".$_REQUEST['Address']."', '".$_REQUEST['Quantity']."', '".$_REQUEST['Items']."')";
$res=mysqli_query($con,$sql);

$email="sandhyadasari03@gmail.com";
$to="sandyasandy2220@gmail.com";
$subject="form submission";
$msg="Name : ".$_REQUEST['Username']."\n".$_REQUEST['Address']."\n\n";
$h="From : $email";
if(mail("sandhyadasari03@gmail","hi", "hello", "From: sandyasandy2220@gmail")){
echo "sent";
}
if($res)
{
echo '<script type="text/javascript">alert("Thank you for donating");</script>';
#header("Location:log.html");
}
else
{
echo "There is some problem in inserting record";
}

}
}

?>