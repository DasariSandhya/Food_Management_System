<?php     


$con=new mysqli("localhost","root","","project");
if(! $con)
{
die('Connection Failed'.mysql_error());
}


//mysql_select_db($database,$con);
if(isset($_REQUEST['submit'])!='')
{
if($_REQUEST['Name']=='' || $_REQUEST['Phone']=='' || $_REQUEST['email']=='' || $_REQUEST['Address']==''|| $_REQUEST['Password']=='')
{
echo "please fill the empty field.";
}
else
{
$sql="insert into registration(Name,Phone_no,Email,Address,Password) values ('".$_REQUEST['Name']."', '".$_REQUEST['Phone']."', '".$_REQUEST['email']."', '".$_REQUEST['Address']."','".$_REQUEST['Password']."')";
$res=mysqli_query($con,$sql);
if($res)
{
#echo "Record successfully inserted";
header("Location:log.html");
}
else
{
echo "There is some problem in inserting record";
}

}
}

?>