<?php     


$con=new mysqli("localhost","root","","project");
if(! $con)
{
die('Connection Failed'.mysql_error());
}

//mysql_select_db($database,$con);
if(isset($_REQUEST['submit'])!='')
{
if($_REQUEST['Username']=='' || $_REQUEST['Address']=='' || $_REQUEST['Quantity']=='' || $_REQUEST['Items']=='')
{
echo "please fill the empty field.";
}
else
{
$sql="insert into fooddetails(Username,Address,Quantity,Items) values ('".$_REQUEST['Username']."', '".$_REQUEST['Address']."', '".$_REQUEST['Quantity']."', '".$_REQUEST['Items']."')";
$res=mysqli_query($con,$sql);
if($res)
{
echo '<script type="text/javascript">alert("Thank you for donating");</script>';
#header("Location:log.html");
}
else
{
echo "There is some problem in inserting record";
}

}
}

?>
