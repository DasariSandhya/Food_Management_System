
<?php


$email=$_POST['email'];
$password=$_POST['password'];
$con=new mysqli("localhost","root","","project");
if($con->connect_error)
{
	die("failed to connect:".$con->connect_error);
}
else
{
	$stmt=$con->prepare("select * from donor where Email=? and Password=?");
	$stmt->bind_param("is",$email,$password);
	$stmt->execute();
	$stmt_result=$stmt->get_result();
	if(mysqli_num_rows($stmt_result) > 0)
	{
		$data=$stmt_result->fetch_assoc();
		if($data['Password']===$password)
		{
			echo"<h2>Login Successfully</h2>";
			header('Location:donor.html');
		}
		else
		{
			echo"<h2>Invalid Email or Password</h2>";
		}
	}
	else
	{
		echo"<h2>Invalid Email or Password</h2>";
	}
}
?>