<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title> WFM</title>
    <meta name="author" content="Codeconvey" />
    
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <link rel="stylesheet" href="css/login-page.css">
    

    <link rel="stylesheet" href="css/demo.css" />
	
</head>
<body>
		

<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        	<div class="rt-heading"><br><br><br>
            	<h1>FOOD MANAGEMENT SYSTEM</h1>
                <p>You waste life when, you waste good food</p>
            </div>
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
              <div class="Scriptcontent">
                <form class="codehim-form" method="POST" action="donorphp.php">
        <div class="form-title">
            <div class="user-icon gr-bg">
            <i class="fa fa-user"></i>
            </div>
     <h2> enter details </h2>
            </div>
    <label for="name"><i>

    <label for="name"><i class="fa fa-user-icon"></i><b> Username:</b></label>
    <input type="text" name="Username"class="cm-input" placeholder="Enter your Full name as per your ID" required>
        
    <label for="address"><i class="fa fa-address"></i><b> Address:</b></label>
    <input name="Address" type="text" class="cm-input" placeholder="Enter your address" required>
	<label for="quantity" ><b> Quantity:</b></label>
    <input name="Quantity" type="number" class="cm-input" placeholder="Enter the quantity as per KG" required>
    <label for="quantity" ><b> Items:</b></label>
    <input name="Items" type="number" class="cm-input" placeholder="Enter the no.of Items" required>
 <div ng-if="UserInfo.approvedTermsAndConditions || !UserInfo.isAuthenticated">
	<ncy-breadcrumb></ncy-breadcrumb>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<form name="tandc" ng-submit="approveTandC()">
				<div class="panel panel-default" style="margin-top:20px;">
					<div class="panel-body" style="max-height:600px; overflow-y:scroll; background-color:white;">
						<div style="text-align:center;">
							<h3>Terms and Conditions</h3>
							<p><h6>
								By Proceeding You will be accepting that I Donor hereby expressly disclaims all warranties, written or oral,
								statutory, express or implied, including any warranty of wholesomeness, merchantability, condition,
quality, fitness for use, or suitability of the Goods in any respect whatsoever, including any warranty regarding the absence of any defects therein, whether latent or patent; it being understood and
agreed that the Goods are being donated in their current condition as of the date hereof. </h6>
							</p>
						</div>
					</div>
				</div>
				<div style="text-align:center;" ng-if="settings.Authentication.RequireTermsAndConditions && !UserInfo.approvedTermsAndConditions && UserInfo.isAuthenticated">
					<button style="margin:20px;" class="btn btn-primary" type="submit">Agree to Terms and Conditions</button>
				</div>
			</form>
		</div>
	</div>
</div>


        <button type="submit" class="btn-login  gr-bg" name="submit"><b>SUBMIT</b></button>
    </form>



    <?php

    $con=new mysqli("localhost","root","","project");
    if($con->connect_error)
{
	die("failed to connect:".$con->connect_error);
}
else
{
	$stmt="select * from reistration";
    //$query="select * from fooddetails";
    $result=$con->query($stmt);
}
if(isset($_POST['submit']))
{
    $to="smileyramya44@gmail.com";
    $msg="order";
    $sub="fdcjhgvmgftfgv";
    while($rows=mysqli_fetch_assoc($result))
        {
            $e=$rows['Email'] ;
        }
    if($to,$sub,$msg,$e)
    {
        echo"thankyou";

    }
    else{
        echo"wrong";
    }
}


?>
    		
    		</div>
		</div>
    </div>
</section>
     


	</body>
</html>