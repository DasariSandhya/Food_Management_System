
<?php


$email=$_POST['email'];
$password=$_POST['password'];
$con=new mysqli("localhost","root","","project");
if($con->connect_error)
{
	die("failed to connect:".$con->connect_error);
}
else
{
	$stmt=$con->prepare("select * from registration where Email=? and Password=?");
	$stmt->bind_param("is",$email,$password);
	$stmt->execute();
	$stmt_result=$stmt->get_result();
	if(mysqli_num_rows($stmt_result) > 0)
	{
		$data=$stmt_result->fetch_assoc();
		if($data['Password']===$password)
		{
			#echo"<h2>Login Successfully</h2>";
			header('Location:donor.html');
		}
		else
		{
			echo"<h2>Invalid Email or Password</h2>";
		}
	}
	else
	{
		echo"<h2>Invalid Email or Password</h2>";
	}
}



//$host="localhost";
//$user="root";
//$password="";
//$db="test";
//mysqli_connect($host,$user,$password);

//$mysqli = new mysqli($host, $user, "", $db);
//mysqli_select_db($db);

//if(isset($_POST['email'])){
	//$uname=$_POST['email'];
	//$password=$_POST['password'];
	
	//$sql="select * from login where Email='".$uname."'AND Password='".$password."' limit 1";
	//$result=mysqli_query($sql);
	
//	if(mysqli_num_rows($result)==1){
//		echo "You have successfully logged in ";
//		exit();

//	}
//	else{
//		echo "you have entered incorrect password or email ";
//		exit();
//	}
//}


//?>
