<?php
    //include_once('conncet.php');
    $con=new mysqli("localhost","root","","project");
    if($con->connect_error)
    {
	die("failed to connect:".$con->connect_error);
    }
else
{
	$Username=$_GET['Username'];
   // $stmt="delete from fooddetails where Username='$id'";
    //$query="select * from fooddetails";
    //$result=$con->query($stmt);
    $del=mysqli_query($con,"delete from fooddetails where Username='$Username'");
    if($del)
    {
        mysqli_close($con);
        header("location:data.php");
        exit;

    }
    else{
        echo" error";
    }
}
?>

